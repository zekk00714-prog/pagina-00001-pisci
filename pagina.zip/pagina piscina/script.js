/**
 * pisciCor - Lógica Interactiva y Manejo de Contactos
 */

document.addEventListener('DOMContentLoaded', () => {
  // Configuración de números de contacto institucionales
  const PHONE_NUMBERS = {
    line1: {
      raw: '3543634606',
      formatted: '3543 634606',
      waUrl: 'https://wa.me/5493543634606',
      telUrl: 'tel:3543634606'
    },
    line2: {
      raw: '3543613121',
      formatted: '3543 613121',
      waUrl: 'https://wa.me/5493543613121',
      telUrl: 'tel:3543613121'
    }
  };

  // Referencias a elementos del DOM
  const navbar = document.getElementById('navbar');
  const mobileToggle = document.getElementById('mobileToggle');
  const navMenu = document.getElementById('navMenu');
  
  const modalWhatsapp = document.getElementById('modalWhatsapp');
  const modalCall = document.getElementById('modalCall');
  const modalGallery = document.getElementById('modalGallery');
  const galleryModalImg = document.getElementById('galleryModalImg');
  
  const widgetTrigger = document.getElementById('widgetTrigger');
  const widgetMenu = document.getElementById('widgetMenu');
  
  const quoteForm = document.getElementById('quoteForm');

  // ==========================================
  // 1. Scroll & Navbar Efecto Sticky
  // ==========================================
  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });

  // ==========================================
  // 2. Menú Mobile Toggle
  // ==========================================
  if (mobileToggle && navMenu) {
    mobileToggle.addEventListener('click', () => {
      navMenu.classList.toggle('active');
      const icon = mobileToggle.querySelector('i');
      if (icon) {
        if (navMenu.classList.contains('active')) {
          icon.className = 'ri-close-line';
        } else {
          icon.className = 'ri-menu-line';
        }
      }
    });

    // Cerrar menú al hacer clic en un enlace
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        const icon = mobileToggle.querySelector('i');
        if (icon) icon.className = 'ri-menu-line';
      });
    });
  }

  // ==========================================
  // 3. Manejo de Modales de Contacto
  // ==========================================
  window.openWhatsappModal = function(customMessage = '') {
    window.currentCustomWaMsg = customMessage;
    if (modalWhatsapp) {
      modalWhatsapp.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  };

  window.openCallModal = function() {
    if (modalCall) {
      modalCall.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  };

  window.closeModal = function(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('active');
      document.body.style.overflow = '';
    }
  };

  // Cerrar modal al hacer clic en el fondo
  document.querySelectorAll('.modal-backdrop').forEach(backdrop => {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) {
        backdrop.classList.remove('active');
        document.body.style.overflow = '';
      }
    });
  });

  // Event Listeners para opciones dentro del modal WhatsApp
  document.querySelectorAll('.btn-wa-line').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const lineKey = btn.getAttribute('data-line');
      const numberObj = PHONE_NUMBERS[lineKey] || PHONE_NUMBERS.line1;
      
      let finalUrl = numberObj.waUrl;
      const defaultText = encodeURIComponent('Hola pisciCor! Me comunico desde la página web para solicitar información.');
      
      if (window.currentCustomWaMsg) {
        finalUrl += `?text=${encodeURIComponent(window.currentCustomWaMsg)}`;
      } else {
        finalUrl += `?text=${defaultText}`;
      }

      window.open(finalUrl, '_blank');
      closeModal('modalWhatsapp');
    });
  });

  // Event Listeners para opciones dentro del modal Llamada
  document.querySelectorAll('.btn-call-line').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const lineKey = btn.getAttribute('data-line');
      const numberObj = PHONE_NUMBERS[lineKey] || PHONE_NUMBERS.line1;
      window.location.href = numberObj.telUrl;
      closeModal('modalCall');
    });
  });

  // ==========================================
  // 4. Widget Flotante Persistente (Speed Dial)
  // ==========================================
  if (widgetTrigger && widgetMenu) {
    widgetTrigger.addEventListener('click', () => {
      widgetMenu.classList.toggle('active');
    });

    // Cerrar widget si hace clic afuera
    document.addEventListener('click', (e) => {
      if (!widgetTrigger.contains(e.target) && !widgetMenu.contains(e.target)) {
        widgetMenu.classList.remove('active');
      }
    });
  }

  // ==========================================
  // 5. Cotizador Express / Generador de WhatsApp
  // ==========================================
  if (quoteForm) {
    quoteForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const service = document.getElementById('quoteService').value;
      const size = document.getElementById('quoteSize').value;
      const location = document.getElementById('quoteLocation').value;
      const comments = document.getElementById('quoteComments').value;
      
      const selectedPhoneRadio = document.querySelector('input[name="quotePhone"]:checked');
      const selectedPhone = selectedPhoneRadio ? selectedPhoneRadio.value : '3543634606';

      let message = `*SOLICITUD DE PRESUPUESTO - PISCICOR*\n\n`;
      message += `🔹 *Servicio requerido:* ${service}\n`;
      message += `📐 *Medida/Dimensiones:* ${size}\n`;
      if (location) message += `📍 *Ubicación:* ${location}\n`;
      if (comments) message += `📝 *Detalles adicionales:* ${comments}\n\n`;
      message += `_Enviado desde el cotizador web de pisciCor._`;

      const encodedMessage = encodeURIComponent(message);
      const waUrl = `https://wa.me/549${selectedPhone}?text=${encodedMessage}`;

      window.open(waUrl, '_blank');
    });
  }

  // ==========================================
  // 6. Galería Lightbox Preview
  // ==========================================
  window.openGalleryModal = function(imgSrc, titleText) {
    if (modalGallery && galleryModalImg) {
      galleryModalImg.src = imgSrc;
      const titleEl = document.getElementById('galleryModalTitle');
      if (titleEl) titleEl.textContent = titleText || 'Proyecto pisciCor';
      modalGallery.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  };

});
